import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET ?? "secret";
const JWT_EXPIRY = (process.env.JWT_EXPIRY ?? "1h") as jwt.SignOptions["expiresIn"];

export function generateToken(userId: string): string {
  return jwt.sign({ sub: userId }, JWT_SECRET, { expiresIn: JWT_EXPIRY });
}

// Run directly: bun run apps/gateway/generateToken.ts <userId>
const userId = process.argv[2] ?? "user123";
const token = generateToken(userId);
console.log(`\nGenerated token for userId: ${userId}`);
console.log(`\nToken:\n${token}`);
console.log(`\nWebSocket URL:\nws://localhost:4000/ws?token=${token}\n`);
